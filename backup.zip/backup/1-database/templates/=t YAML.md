---
title: <%tp.file.title%>
date-created: 2021.08.05, 22:28
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# <%tp.file.title%>

- #π/определение:
	- **<%tp.file.title%>** — <%tp.file.cursor(1)%>

---

# Библиография

-
