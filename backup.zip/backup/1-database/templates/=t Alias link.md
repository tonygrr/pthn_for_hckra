---
title: =t Alias link
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Alias link

[[<%tp.file.cursor(1)%>|<% tp.file.selection() %>]]
