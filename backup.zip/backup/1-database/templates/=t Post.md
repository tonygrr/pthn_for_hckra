---
title: =t Post
date-created: 2022.04.13, 13:12
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Post

title: "<%tp.file.title%>"
