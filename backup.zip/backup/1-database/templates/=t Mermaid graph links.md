---
title: =t Mermaid graph links
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Mermaid graph links

```mermaid
graph LR
A[<%tp.file.cursor()%>] --> B

class A internal-link;
```
