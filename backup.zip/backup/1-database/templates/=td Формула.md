---
title: =td Формула
date-created: 2022.05.03, 17:15
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =td Формула

#π/формула:
