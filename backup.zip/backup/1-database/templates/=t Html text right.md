---
title: =t Html text right
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Html text right

<p align="right"><%tp.file.cursor()%></p>
