<split even gap="2">
<%tp.file.cursor()%>
</split>