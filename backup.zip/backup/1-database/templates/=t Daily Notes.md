---
title: '<%tp.date.now("DD MMMM YYYY")%>'
date-created: 2021.09.05, 12:57
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# <%tp.date.now("DD MMMM YYYY")%>

- <%tp.file.cursor(1)%>
