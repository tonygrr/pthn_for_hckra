---
title: =t Цветной текст
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Цветной текст

<span style="color:green"><%tp.file.cursor()%></span>
