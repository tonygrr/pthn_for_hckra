---
title: <%tp.file.title%>
date-created: 2023.02.27, 19:47
date-modified: 2023.04.03, 22:06
aliases: []
tags: [кинематограф]
---

# <%tp.file.title%>

- **<%tp.file.title%>** — <%tp.file.cursor(9)%>

> [!info]+ Метаданные
> - обложка:: <%tp.file.cursor(0)%>
> - годы:: [[<%tp.file.cursor(1)%>]]
> - страна:: [[<%tp.file.cursor(2)%>]]
> - жанры:: [[<%tp.file.cursor(3)%>]]
> - состав:: [[<%tp.file.cursor(4)%>]]
> - оценка:: "<%tp.file.cursor(8)%>"

## Мнение

- <%tp.file.cursor(10)%>

## Цитаты

>

---

# Библиография

-
