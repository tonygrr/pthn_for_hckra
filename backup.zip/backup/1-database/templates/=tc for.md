---
title: =tc for
date-created: 2022.10.05, 08:04
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =tc for

for(<%tp.file.cursor(1)%>) {

	<%tp.file.cursor(2)%>

}

<%tp.file.cursor(3)%>
