---
title: =t Html text big
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Html text big

<big><big><%tp.file.cursor()%></big></big>
