---
title: =t Mermaid flowchart TB
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Mermaid flowchart TB

```mermaid
flowchart TB
<%tp.file.cursor()%>
```
