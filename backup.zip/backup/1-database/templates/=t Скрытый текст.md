---
title: =t Скрытый текст
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Скрытый текст

<details>
	<summary> Скрытый текст </summary>
<%tp.file.cursor()%>
</details>
