---
title: =t Ресурсы  Википедия
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t Ресурсы Википедия

[Википедия](<%tp.file.cursor()%>)
