---
title: =t LTX dfrac
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t LTX dfrac

\dfrac{<%tp.file.cursor(1)%>}{<%tp.file.cursor(2)%>}
