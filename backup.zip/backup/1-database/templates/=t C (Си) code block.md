---
title: =t C (Си) code block
date-created: 2022.10.04, 00:14
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t C (Си) code block

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	<%tp.file.cursor(0)%>
}
```
