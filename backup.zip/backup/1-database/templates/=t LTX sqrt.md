---
title: =t LTX sqrt
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t LTX sqrt

\sqrt{<%tp.file.cursor(1)%>}
