---
title: =t LTX tag of formulas (номер для формул)
date-created: 2021.06.03, 10:33
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t LTX tag of formulas (номер для формул)

\tag{<%tp.file.cursor(1)%>}
