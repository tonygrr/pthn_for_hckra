---
title: <%tp.file.title%>
date-created: 2022.11.01, 23:03
date-modified: 2023.04.03, 22:06
aliases: []
tags: [кинематограф]
---

# <%tp.file.title%>

- **<%tp.file.title%>** — <%tp.file.cursor(9)%>

> [!info]+ Метаданные
> - обложка:: <%tp.file.cursor(0)%>
> - год:: [[<%tp.file.cursor(1)%>]]
> - страна:: [[<%tp.file.cursor(2)%>]]
> - жанр:: [[<%tp.file.cursor(3)%>]]
> - режиссёр:: [[<%tp.file.cursor(4)%>]]
> - главные-герои:: <%tp.file.cursor(5)%>
> - в-главных-ролях:: <%tp.file.cursor(6)%>
> - смотреть:: <%tp.file.cursor(7)%>
> - оценка:: "<%tp.file.cursor(8)%>"

## Мнение

- <%tp.file.cursor(10)%>

## Цитаты

>

---

# Библиография

-
