---
title: =t LTX $ $
date-created: 2021.07.26, 18:17
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =t LTX $ $

$<%tp.file.cursor(1)%>$<%tp.file.cursor(2)%>
