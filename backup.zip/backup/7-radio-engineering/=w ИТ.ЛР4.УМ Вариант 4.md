---
title: =w ИТ.ЛР4.УМ Вариант 4
date-created: 2022.12.01, 19:03
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# =w ИТ.ЛР4.УМ Вариант 4

```c
#include <stdio.h>

void squeeze(char s1[], char s2[]);

int main() {
  char line1[] = "12345ggggg6789", line2[] = "gg";
  squeeze(line1, line2);
  printf("%s", line1);
  return 0;
}

void squeeze(char s1[], char s2[]) {
  int k = 0, i, j;
  for (i = 0; s1[i]; i++) {
    for (j = 0; s2[j]; j++) {
      if (s2[j] == s1[i])
        break;
    }
    if (s1[i] != s2[j])
      s1[k++] = s1[i];
  }
  s1[k] = 0;
}
```
