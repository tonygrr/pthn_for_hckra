---
title: =w ИТ.ЛР2.РА.В7
date-created: 2022.10.25, 11:19
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.РА.В7

## Задание

Определить, какая из точек A(x1, y1), B(x2, y2) находится ближе к началу координат.

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void) {
    int x1, x2, y1, y2;
    double l1, l2;
    printf("Vvedite x1,y1,x2,y2,R\n");
    scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
    printf("x1=%d\ny1=%d\nx2=%d\ny2=%d\n",x1,y1,x2,y2);
    
    l1=sqrt(pow(x1,2)+pow(y1,2));
    l2=sqrt(pow(x2,2)+pow(y2,2));  
    
    printf("l1=%f\nl2=%f\n",l1,l2);
    
    if(l1<l2)
        printf("Tochka A(x1,y1)");
        else
            printf("Tochka B(x2,y2)");
    return 0;
}
```
