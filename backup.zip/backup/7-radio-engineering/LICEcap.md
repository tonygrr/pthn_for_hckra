---
title: LICEcap
date-created: 2022.10.24, 20:01
date-modified: 2023.04.03, 22:06
aliases: []
tags: [windows, apps]
---

# LICEcap

- #π/определение:
	- **LICEcap** — самый простой и примитивный создатель gif-записи экрана.

---

# Библиография

- [[@CockosIncorporatedLICEcap]]
