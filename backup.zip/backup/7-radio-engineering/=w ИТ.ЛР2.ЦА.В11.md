---
title: =w ИТ.ЛР2.ЦА.В11
date-created: 2022.10.25, 11:39
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.ЦА.В11

## Задание

При заданном натуральном $N$ вычислить сумму $S=\dfrac{1}{\sin_{1}}+\dfrac{1}{\sin_{1}+\sin_{2}}+\dots+\dfrac{1}{\sin_{1}+\sin_{2}+\sin_{N}}$.

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	int i, N;
	float S, Z;
	printf("Введите N\n");
	scanf("%d", &N);
	for(i=1; i<=N; i++) {
		Z+=sin(i);
		S+=1/Z;
		}
	printf("S=%f",S);
}
```
