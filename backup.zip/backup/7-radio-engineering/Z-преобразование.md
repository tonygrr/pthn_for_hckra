---
title: Z-преобразование
date-created: 2021.04.14, 10:28
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# Z-преобразование

$$X(Z)=\displaystyle\sum_{n=-\infty}^{+\infty}x(n)Z^{-n}$$

где $Z=e^{(\alpha + j\omega)}=e^\alpha e^{j\omega}$

![[Pasted image 20210301135351.png]]
