---
title: =w ИТ.ЛР3.Ф.В4
date-created: 2022.10.25, 12:02
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит, функции]
---

# =w ИТ.ЛР3.Ф.В4

- Выполнить на replit:
	- https://replit.com/@tonygrr/LR3V4#main.c

## Задание

- Формула: $Z=\sin\left( \sum_{K=3}^{10}Y_{K} \right)+B\cos\left( \sum_{K=6}^{20}Y_{K} \right)+\dfrac{C}{\sum_{K=11}^{30}Y_{K}}$;
- Функция: $Y_K=b \cdot \dfrac{\ln (10 \cdot(A \cdot K+C))}{\sqrt{K+A+B}}$,
	- где $b=1, A=0, B=9, C=1$.
- Расчет сумм в формуле и расчет $Y_K$ должны быть оформлены в виде отдельных функций.

## Реализация

```c
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/* Прототипы всех функций: */
float sum1(int K1, int Kk1);
float sum2(int K2, int Kk2);
float sum3(int K3, int Kk3);
float Yk(int K, int b, int A, int B, int C);

int main() {
	int K1 = 3, K2 = 6, K3 = 11, Kk1 = 10, Kk2 = 20, Kk3 = 30;
	int b = 1, A = 0, B = 9, C = 1;
	float Z, s1, s2, s3;
	s1 = sum1(K1, Kk1);
	s2 = sum2(K2, Kk2);
	s3 = sum3(K3, Kk3);
	Z = sin(s1) + B * cos(s2) + C / s3;
	printf("\nЗначения сумм:\n");
	printf("s1=%f\n", s1);
	printf("s2=%f\n", s2);
	printf("s3=%f\n", s3);
	printf("\nЗначение Z:\n");
	printf("z=%f\n", Z);
	return 0;
}

/* Определение функции для вычисления Yk */
float Yk(int K, int b, int A, int B, int C) {
	return b * (log(10 * (A * K + C))) / (sqrt(K + A + B));
}

/* Определение функции для вычисления суммы №1 */
float sum1(int K1, int Kk1) {
	int i1;
	int b = 1, A = 0, B = 9, C = 1;
	float Yk1;
	printf("Значения Yk1:\n");
	for (i1 = K1; i1 <= Kk1; i1++) {
		Yk1 = Yk(i1, b, A, B, C);
		Yk1 += Yk1;
		printf("Yk1.%d=%f\n", i1, Yk1);
	}
	return Yk1;
}

/* Определение функции для вычисления суммы №2 */
float sum2(int K2, int Kk2) {
	int i2;
	int b = 1, A = 0, B = 9, C = 1;
	float Yk2;
	printf("\nЗначения Yk2:\n");
	for (i2 = K2; i2 <= Kk2; i2++) {
		Yk2 = Yk(i2, b, A, B, C);
		Yk2 += Yk2;
		printf("Yk2.%d=%f\n", i2, Yk2);
	}
	return Yk2;
}

/* Определение функции для вычисления суммы №3 */
float sum3(int K3, int Kk3) {
	int i3;
	int b = 1, A = 0, B = 9, C = 1;
	float Yk3;
	printf("\nЗначения Yk3:\n");
	for (i3 = K3; i3 <= Kk3; i3++) {
		Yk3 = Yk(i3, b, A, B, C);
		Yk3 += Yk3;
		printf("Yk3.%d=%f\n", i3, Yk3);
	}
	return Yk3;
}
```

## Результат выполнения

```
Значения Yk1:
Yk1.3=1.329398
Yk1.4=1.277244
Yk1.5=1.230783
Yk1.6=1.189050
Yk1.7=1.151293
Yk1.8=1.116918
Yk1.9=1.085449
Yk1.10=1.056499

Значения Yk2:
Yk2.6=1.189050
Yk2.7=1.151293
Yk2.8=1.116918
Yk2.9=1.085449
Yk2.10=1.056499
Yk2.11=1.029747
Yk2.12=1.004930
Yk2.13=0.981826
Yk2.14=0.960244
Yk2.15=0.940026
Yk2.16=0.921034
Yk2.17=0.903148
Yk2.18=0.886265
Yk2.19=0.870295
Yk2.20=0.855159

Значения Yk3:
Yk3.11=1.029747
Yk3.12=1.004930
Yk3.13=0.981826
Yk3.14=0.960244
Yk3.15=0.940026
Yk3.16=0.921034
Yk3.17=0.903148
Yk3.18=0.886265
Yk3.19=0.870295
Yk3.20=0.855159
Yk3.21=0.840785
Yk3.22=0.827113
Yk3.23=0.814087
Yk3.24=0.801657
Yk3.25=0.789780
Yk3.26=0.778416
Yk3.27=0.767528
Yk3.28=0.757085
Yk3.29=0.747057
Yk3.30=0.737417

Значения сумм:
s1=1.056499
s2=0.855159
s3=0.737417

Значение Z:
z=8.131612
```
