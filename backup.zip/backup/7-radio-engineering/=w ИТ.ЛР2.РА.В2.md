---
title: =w ИТ.ЛР2.РА.В2
date-created: 2022.10.25, 11:19
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.РА.В2

## Задание

Проверить, попала ли заданная точка в заштрихованную область.

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void) {
    int x, y, r, R;
    double l;
    printf("Vvedite x,y,r,R\n");
    scanf("%d%d%d%d",&x,&y,&r,&R);
    printf("x=%d\ny=%d\nr=%d\nR=%d\n",x,y,r,R);
    
    l=sqrt(pow(x,2)+pow(y,2));
    
    printf("l=%f\n",l);
    
    if(l<=R && l>=r)
        printf("Vhodit");
        else
            printf("Ne vhodit");
    return 0;
}
```
