---
title: =w ИТ.ЛР3.Ф.В1
date-created: 2022.10.24, 23:48
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит, функции]
---

# =w ИТ.ЛР3.Ф.В1

- Выполнить на replit:
	- https://replit.com/@tonygrr/LR3V1#main.c

## Задание

- Формула: $Z=10 \cdot A \cdot \sum_{K=2}^{10} Y_K+5 \cdot B \cdot \sum_{K=4}^{20} Y_K+\dfrac{2 \cdot C}{\sum_{K=3}^{15} Y_K}$;
- Функция: $Y_K=a \cdot \dfrac{A \cdot K+B \cdot K^2}{A+B^2+C^2}$,
	- где $a=1, A=5, B=5, C=2$.
- Расчет сумм в формуле и расчет $Y_K$ должны быть оформлены в виде отдельных функций.

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Прототипы всех функций: */
float sum1(int K1, int Kk1);
float sum2(int K2, int Kk2);
float sum3(int K3, int Kk3);
float Yk(int K, int a, int A, int B, int C);

int main() {
	int K1=2, K2=4, K3=3, Kk1=10, Kk2=20, Kk3=15;
	int a=1, A=5, B=5, C=2;
	float Z, s1, s2, s3;
	s1=sum1(K1,Kk1);
	s2=sum2(K2,Kk2);
	s3=sum3(K3,Kk3);
	Z=10*A*s1+5*B*s2+(2*C)/s3;
	printf("\nЗначения сумм:\n");
	printf("s1=%f\n",s1);
	printf("s2=%f\n",s2);
	printf("s3=%f\n",s3);
	printf("\nЗначение Z:\n");
	printf("z=%f\n",Z);  
	return 0;
}

/* Определение функции для вычисления Yk */
float Yk(int K, int a, int A, int B, int C) {
	return a*(A*K+B*pow(K,2))/(A+pow(B,2)+pow(C,2));
}

/* Определение функции для вычисления суммы №1 */
float sum1(int K1, int Kk1) {
	int i1;
	int a=1, A=5, B=5, C=2;
	float Yk1;
	printf("Значения Yk1:\n");
	for(i1=K1; i1<=Kk1; i1++) {
		Yk1=Yk(i1,a,A,B,C);
		Yk1+=Yk1;
		printf("Yk1.%d=%f\n",i1,Yk1);
	}
	return Yk1;
}

/* Определение функции для вычисления суммы №2 */
float sum2(int K2, int Kk2) {
	int i2;
	int a=1, A=5, B=5, C=2;
	float Yk2;
	printf("\nЗначения Yk2:\n");
	for(i2=K2; i2<=Kk2; i2++) {
		Yk2=Yk(i2,a,A,B,C);
		Yk2+=Yk2;
		printf("Yk2.%d=%f\n",i2,Yk2);
	}
	return Yk2;
}

/* Определение функции для вычисления суммы №3 */
float sum3(int K3, int Kk3) {
	int i3;
	int a=1, A=5, B=5, C=2;
	float Yk3;
	printf("\nЗначения Yk3:\n");
	for(i3=K3; i3<=Kk3; i3++) {
		Yk3=Yk(i3,a,A,B,C);
		Yk3+=Yk3;
		printf("Yk3.%d=%f\n",i3,Yk3);
	}
	return Yk3;
}
```

## Результат выполнения

```
Значения Yk1:
Yk1.2=1.764706
Yk1.3=3.529412
Yk1.4=5.882353
Yk1.5=8.823529
Yk1.6=12.352942
Yk1.7=16.470589
Yk1.8=21.176470
Yk1.9=26.470589
Yk1.10=32.352940

Значения Yk2:
Yk2.4=5.882353
Yk2.5=8.823529
Yk2.6=12.352942
Yk2.7=16.470589
Yk2.8=21.176470
Yk2.9=26.470589
Yk2.10=32.352940
Yk2.11=38.823528
Yk2.12=45.882355
Yk2.13=53.529411
Yk2.14=61.764706
Yk2.15=70.588234
Yk2.16=80.000000
Yk2.17=90.000000
Yk2.18=100.588234
Yk2.19=111.764709
Yk2.20=123.529411

Значения Yk3:
Yk3.3=3.529412
Yk3.4=5.882353
Yk3.5=8.823529
Yk3.6=12.352942
Yk3.7=16.470589
Yk3.8=21.176470
Yk3.9=26.470589
Yk3.10=32.352940
Yk3.11=38.823528
Yk3.12=45.882355
Yk3.13=53.529411
Yk3.14=61.764706
Yk3.15=70.588234

Значения сумм:
s1=32.352940
s2=123.529411
s3=70.588234

Значение Z:
z=4705.938965
```
