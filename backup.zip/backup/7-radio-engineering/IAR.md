---
title: IAR
date-created: 2022.03.27, 22:10
date-modified: 2022.11.30, 23:36
aliases: []
tags: [iar]
---

# IAR

## Лицензия

```
9400-637-474-0369
```

## Настройка

- Создание `.hex` файла: `Options >> Output converter`.

## Решение проблем

- Решение проблемы с лицензией (которое у меня не сработало):
	- [2018. *Using Windows 10 version 1803 and newer with dongle license*](zotero://select/items/1_HMHWZLKS)

## Библиография

- [Плейлист Youtube](https://www.youtube.com/playlist?list=PLyCllaYmci7YjuoNQ11JodzLm6_c4tOXh)
