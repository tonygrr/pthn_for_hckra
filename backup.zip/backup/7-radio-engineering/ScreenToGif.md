---
title: ScreenToGif
date-created: 2022.10.24, 20:03
date-modified: 2023.04.03, 22:06
aliases: []
tags: [windows, apps]
---

# ScreenToGif

- #π/определение:
	- **ScreenToGif** — продвинутая программа для записи экрана, которая на выходе способна выдать отличного качества gif-ку.

---

# Библиография

- [[@ManarinScreenToGifFeatures]]
