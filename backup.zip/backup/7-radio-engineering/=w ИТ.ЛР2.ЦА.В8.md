---
title: =w ИТ.ЛР2.ЦА.В8
date-created: 2022.10.25, 11:38
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.ЦА.В8

## Реализация

### Вариант 1

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	int x;
	float F;
	for(x=0; x<=10; x++) {
		if(x<=7) {
			F=-3*x+9;
			printf("x=%d, F=%f\n",x,F);
		}
		else {
			F=1/(x-7);
			printf("x=%d, F=%f\n",x,F);
		}
	}
}
```

### Вариант 2

```c
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
	int x;
	float F;
	for (x = 0; x <= 10; x++) {
		if (x == 0)
			printf("x <= 7:\n");
		if (x <= 7) {
			F = -3 * x + 9;
			printf("F = %3.0f\n", F);
		}
    if (x == 7) {
      printf("x > 7:\n");
    }
    if (x > 7) {
      F = 1 / (x - 7);
      printf("F = %3.0f\n", F);
    }
  }
}    
```
