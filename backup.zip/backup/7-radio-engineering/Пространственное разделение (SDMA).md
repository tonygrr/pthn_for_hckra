---
title: Пространственное разделение (SDMA)
date-created: 2022.05.23, 12:35
date-modified: 2023.02.07, 13:44
aliases: []
tags: [радиолокация, цос]
---

# Пространственное разделение (SDMA)

- #π/иллюстрация:
	- ![[Pasted image 20220521112657.png]]

---

# Библиография

- [[@ФлаксманRadiotehnicheskieSistemyPeredachi]]
