---
title: =w ИТ.ЛР2.РА.В1
date-created: 2022.10.25, 11:18
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.РА.В1

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void) {
    int a,b,c,d,e,f;
    double l1,l2,l3,t,r;
    printf("Vvedite a,b,c,d,e,f\n");
    scanf("%d%d%d%d%d%d", &a,&b,&c,&d,&e,&f);
    printf("a=%d,b=%d,c=%d,d=%d,e=%d,f=%d\n",a,b,c,d,e,f);
    
    l1=sqrt(pow((a-c),2)+pow((b-d),2));
	l2=sqrt(pow((c-e),2)+pow((d-f),2));
	l3=sqrt(pow((a-e),2)+pow((b-f),2));
    
    printf("l1=%f\nl2=%f\nl3=%f\n",l1,l2,l3);

	if(l1>l2)
		t=l1;
		else t=l2;
	
	if(t>l3)
		r=t;
    	else r=l3;

	printf("Naibolshee rasstoyanie mejdy tochkami = %f\n",r);

    return 0;
}
```
