---
title: =w ИТ.ЛР2.ЦА.В3
date-created: 2022.10.25, 11:37
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.ЦА.В3

## Задание

Определить наибольший член последовательности действительных чисел $x_{i}$, где $i=0,1,\dots,4$. За начальное значение $x_{max}$ принять нулевой элемент массива, т. е. $x_{0}$.

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main () {
	int x;
	int max=0;
	printf("Vvedite 4 deistvitelnye chisla. Posle etogo vvedite 0.\n");
	
	do {
		scanf("%d", &x);

		if(x>max)
			max=x;
	}
	while(x!=0);
	printf("max=%d\n",max);
}
```
