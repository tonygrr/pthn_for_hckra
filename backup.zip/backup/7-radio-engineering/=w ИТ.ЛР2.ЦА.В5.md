---
title: =w ИТ.ЛР2.ЦА.В5
date-created: 2022.10.25, 11:38
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.ЦА.В5

## Задание

Вычислить сумму $S=\sum_{i=0}^{5}x_{i}$ членов последовательности действительных чисел, где $i=0,1,\dots,5$.

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	int i, x, sum=0;
	printf("Введите 5 действительных чисел.\n");
	for(i=1; i<=5; i++) {
		scanf("%d",&x);
		sum=sum+x;
		}
	printf("sum=%d", sum);
}
```
