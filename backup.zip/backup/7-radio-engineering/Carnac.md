---
title: Carnac
date-created: 2022.10.24, 20:09
date-modified: 2023.04.03, 22:06
aliases: []
tags: [windows, apps]
---

# Carnac

- #π/определение:
	- **Carnas** — визуализатор нажимаемых клавиш.
- Тип: портативная.

---

# Библиография

- [Carnac](file:///D:%5Cmojo-risin%5C+resources%5CCarnac) — папка с файлом программы.
- [[@Code52Carnac2022]]
