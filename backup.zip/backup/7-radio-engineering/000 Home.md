---
title: 000 Home
date-created: 2021.10.27, 20:39
date-modified: 2023.04.03, 22:06
aliases: []
tags: [moc]
---

# 000 Home

- [[Inbox]]

## Скрипты

- [content.bat](file:///D:%5Cmojo-risin%5C+resources%5CScripts%5Ccontent.bat)
- [backup.bat](file:///D:%5Cmojo-risin%5C+resources%5CScripts%5Cbackup.bat)

## В работе

```dataview
list
from #состояние/активно or #состояние/доработать
```

## Зона ответственности

- [[010 Radio Engineering]] — на что ушла молодость.
- [[020 Завод 70-летия победы]] — материал с базовой кафедры.
- [[Семья]]

## Личное

- [[030 Личное]]
- [[040 Проекты]]
- [[050 Люди]]

## Искусство

- [[060 Музыка]]
- [[070 Литература]]

## Знания

- [[080 Знания]]
- [[090 Spaced Repetition Flashcards]]
