---
title: CapsLock to Ctrl
date-created: 2022.10.12, 12:48
date-modified: 2023.04.03, 22:06
aliases: []
tags: [windows]
---

# CapsLock to Ctrl

## Переназначение ч/з PowerShell

- Открыть PowerShell от имени администратора.
- Ввести следующие команды:

```powershell
$hexified = "00,00,00,00,00,00,00,00,02,00,00,00,1d,00,3a,00,00,00,00,00".Split(',') | % { "0x$_"};
```

```powershell
$kbLayout = 'HKLM:\System\CurrentControlSet\Control\Keyboard Layout';
```

```powershell
New-ItemProperty -Path $kbLayout -Name "Scancode Map" -PropertyType Binary -Value ([byte[]]$hexified);
```

---

# Библиография

- [[@262588213843476RemapCapsLock]]
