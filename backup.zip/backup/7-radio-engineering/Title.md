---
title: Test Slides
date-created: 2021.08.05, 22:28
date-modified: 2023.11.27, 21:08
aliases: 
tags: 
center: "false"
---

<!-- .slide: data-auto-animate -->

# Title

---
<!-- .slide: data-auto-animate -->

# Title

## **Subtitle**

### *Author - 2022*

---
<!-- .slide: data-auto-animate -->

# Title

## **Subtitle**

### *Author - 2022*

- Мило дело, господа. 

---

<!-- .slide: data-auto-animate -->

# Title

## **Subtitle**

### *Author - 2022*

- Мило дело, господа. 
- Я просто похлопаю стоя. Буду говорить что захочу и ничего вы мне не сделаете. А позже протестирую картинки!

---

![[2.gif|700x500]]