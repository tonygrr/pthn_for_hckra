---
title: =w ИТ.ЛР2.РА.В9
date-created: 2022.10.25, 11:20
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.РА.В9

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void) {
	int a,b,c,l=0;
	printf("Vvedite a,b,c\n");
	scanf("%d%d%d",&a,&b,&c);
	printf("a=%d\nb=%d\nc=%d\n",a,b,c);

	if(a>0)
		l=l+1;
		else l=l;
	if(b>0)
		l=l+1;
		else l=l;
	if(c>0)
		l=l+1;
		else l=l;

	printf("Kol-vo otricatelnyh chisel = %d",l);

return 0;
}
```
