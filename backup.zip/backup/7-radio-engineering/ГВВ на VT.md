---
title: ГВВ на VT
date-created: 2021.04.14, 10:42
date-modified: 2023.04.03, 22:06
aliases: []
tags: []
---

# ГВВ на VT

В данном ГВВ в качестве АЭ используется БТ.

![[Pasted image 20201229114501.png]]
