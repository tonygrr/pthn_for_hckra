---
title: =w ИТ.ЛР2.ЦА.В12
date-created: 2022.10.25, 11:39
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.ЦА.В12

## Реализация

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	float L[7];
	int n=7, i;
    float x=0.5;
	L[0]=1;
	L[1]=x-1;
	printf("%f, %f, ",L[0],L[1]);
	for(i=2; i<=n; i++) {
		L[i]=(x-2*i+1)*L[i-1]-pow((i-1),2)*L[i-2];
		printf("%f," ,L[i]);
	}
}
```
