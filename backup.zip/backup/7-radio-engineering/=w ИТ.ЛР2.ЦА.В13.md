---
title: =w ИТ.ЛР2.ЦА.В13
date-created: 2022.10.25, 11:39
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.ЦА.В13

## Задание

Вычислить сумму всех членов последовательности $x_{i}$, $i=1,2,\dots,n$, за исключением членов, равных $m,k$.

## Реализация

```c
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
	int i, n, x, sum = 0, k, m;
	printf("Введите длительность последовательности n и индексы k, m её "
		   "членов, исключенных из подсчёта суммы последовательности:\n");
	printf("Введите n=");
	scanf("%d", &n);
	printf("Введите k=");
	scanf("%d", &k);
	printf("Введите m=");
	scanf("%d", &m);

	printf("Введите %d действительных чисел:\n", n);

	for (i = 1; i <= n; i++) {
		printf("x%d=", i);
		scanf("%d", &x);
		if (i == k || i == m)
			sum = sum;
		else
			sum = sum + x;
	}
	printf("Сумма всех членов последовательности равна %d.", sum);

	return 0;
}
```
