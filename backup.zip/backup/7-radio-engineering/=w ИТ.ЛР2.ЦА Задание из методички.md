---
title: =w ИТ.ЛР2.ЦА Задание из методички
date-created: 2022.10.25, 11:24
date-modified: 2023.04.03, 22:06
aliases: []
tags: [ит]
---

# =w ИТ.ЛР2.ЦА Задание из методички

## Задание из методички

```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void) {
	float a, b, n, h, x, T;
	int i;
	printf("Vvedite a,b,n\n");
	scanf("%f%f%f",&a,&b,&n);
	h=(b-a)/(n-1);
	printf("Tablica znacheniy x, T\n");
	for(i=1; i<=n; i++) {
		x=a+(i-1)*h;
		T=(4*pow(x,2)-3)*x;
		printf("%f %f\n",x,T);
	}
}
```
